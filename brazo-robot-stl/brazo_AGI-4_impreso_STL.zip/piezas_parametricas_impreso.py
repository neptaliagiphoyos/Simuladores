import manifold3d as m, numpy as np, trimesh, sys, json
M=m.Manifold
OUT=sys.argv[1]
def box(x,y,z): return M.cube([x,y,z],False)
def boxc(cx,cy,cz,x,y,z): return M.cube([x,y,z],True).translate([cx,cy,cz])
def cyl(h,r,n=64): return M.cylinder(h,r,r,n)
def U(*a):
    r=a[0]
    for b in a[1:]: r=r+b
    return r
INFO={}
def save(man,name,qty,desc):
    me=man.to_mesh(); t=trimesh.Trimesh(np.array(me.vert_properties)[:,:3],np.array(me.tri_verts))
    t.apply_translation([0,0,-t.bounds[0][2]])
    assert t.is_watertight, name
    t.export(f"{OUT}/{name}.stl")
    INFO[name]=dict(qty=qty,desc=desc,bbox=(t.bounds[1]-t.bounds[0]).round(1).tolist(),g=round(t.volume/1000*1.24*0.55,1))
    print(name,INFO[name])
    return t
# --- servos ---
G={'L':40.9,'W':20.1,'hx':49.5,'hy':10,'hr':1.7,'off':10.2}         # MG996R (holgura incluida)
S={'L':23.1,'W':12.5,'hx':27.8,'hy':0,'hr':1.0,'off':5.9}           # MG90S
def servo_cut(s,cx,cy,T,along='x'):
    """ventana + agujeros de orejas, centro del cuerpo en (cx,cy); 'along' = eje largo"""
    L,W=s['L'],s['W']
    if along=='x': c=boxc(cx,cy,T/2,L,W,T+4)
    else: c=boxc(cx,cy,T/2,W,L,T+4)
    hs=[]
    for sx in (-1,1):
        for sy in ((-1,1) if s['hy'] else (0,)):
            dx,dy=sx*s['hx']/2,sy*s['hy']/2
            if along!='x': dx,dy=dy,dx
            hs.append(cyl(T+4,s['hr'],24).translate([cx+dx,cy+dy,-2]))
    return U(c,*hs)
def horn_cut(cx,cy,T,r1,r2,w,rec_r,rec_d,top=False):
    sl=[]
    for a in (45,135,225,315):
        s=U(boxc((r1+r2)/2,0,T/2,r2-r1,w,T+4),cyl(T+4,w/2,20).translate([r1,0,-2]),cyl(T+4,w/2,20).translate([r2,0,-2]))
        sl.append(s.rotate([0,0,a]).translate([cx,cy,0]))
    z0=T-rec_d if top else -1
    return U(*sl,cyl(rec_d+1,rec_r).translate([cx,cy,z0]))
BIG=dict(r1=5,r2=11.5,w=2.3,rec_r=4.0,rec_d=2.2)
SMALL=dict(r1=3.5,r2=8.5,w=1.6,rec_r=3.0,rec_d=1.6)

# 1) BASE: carcasa (piso + pared) ----------------------------------
R=70; H=34
car=cyl(4,R,128)+ (cyl(H,R,128)-cyl(H+2,R-3,128).translate([0,0,2]))
bosses=[]; bh=[]
for a in (45,135,225,315):
    x,y=62*np.cos(np.radians(a)),62*np.sin(np.radians(a))
    bosses.append(cyl(H,4.5,32).translate([x,y,0])); bh.append(cyl(H,1.3,20).translate([x,y,6]))
car=car+U(*bosses)-U(*bh)
car=car-boxc(R-1,0,4+8,10,26,16)              # salida de cables (USB y 220 V)
# pies de goma: 4 rebajes
save(car,"01_base_carcasa",1,"Piso y pared de la base. Dentro van el ESP32, el PCA9685 y la bornera. Salida de cables al costado.")
# 2) BASE: tapa (servo vertical, eje en el centro) -----------------
tapa=cyl(4,R,128)
tapa=tapa-servo_cut(G,-G['off'],0,4)          # eje del servo en (0,0)
tapa=tapa-U(*[cyl(8,1.7,20).translate([62*np.cos(np.radians(a)),62*np.sin(np.radians(a)),-2]) for a in (45,135,225,315)])
tapa=tapa-cyl(8,6,32).translate([35,0,-2])     # paso de cables
save(tapa,"02_base_tapa",1,"Tapa de la base. Sostiene el MG996R de la base con el eje justo al centro. Se atornilla a la carcasa con 4 M3.")
# 3) PLATO GIRATORIO (se imprime con la falda hacia arriba) ---------
P=cyl(5,52,128)
P=P-horn_cut(0,0,5,top=True,**BIG)             # cara superior en impresión = cara inferior en uso (toca la bocina)
falda=cyl(16,50,128)-cyl(18,40,128).translate([0,0,-1])
P=P+falda.translate([0,0,0])                    # anillo que se apoya en el lazy susan
P=P-horn_cut(0,0,5,top=True,**BIG)
# agujeros para el pie del hombro (ver pieza 4): pie centrado en x=0, y de -10 a -40 (en uso)
for hx in (-14,14):
    for hy in (-17,-33):
        P=P-cyl(10,1.7,20).translate([hx,-hy,-2])   # espejo en y por el volteo
save(P,"03_plato_giratorio",1,"Gira sobre el rodamiento lazy susan. Se atornilla a la bocina del servo de la base por las 4 ranuras.")
# 4) SOPORTE DE HOMBRO (mejilla en L) -------------------------------
# en uso: mejilla en plano x-z, espesor y de -10 a -4 ; pie sobre el plato y de -40 a -4
TH=6; WC=40; zc=4+5+24.75   # centro del cuerpo del servo sobre el pie (z relativo al plato)
HC=zc+24.75+6
# construir en coordenadas de impresión: mejilla acostada (x, "z de uso" como y), espesor como z
mej=box(WC,HC,TH).translate([-WC/2,0,0])
mej=mej-servo_cut(G,0,zc,TH,along='y')
pie=box(WC,5,36).translate([-WC/2,0,0])        # pared que sube = pie
pie_h=U(*[cyl(10,1.7,20).rotate([90,0,0]).translate([hx,8,hz]) for hx in (-14,14) for hz in (13,29)])
ref=U(boxc(-WC/2+2,10,TH+8,4,10,16),boxc(WC/2-2,10,TH+8,4,10,16))
hom=mej+pie+ref-pie_h
save(hom,"04_soporte_hombro",1,"Mejilla en L que sostiene el MG996R del hombro de lado. Se atornilla al plato con 4 M3.")
L0_eje=0
# 5) BRAZO (eslabón 1, 120 mm) --------------------------------------
T1=6
b=boxc(55,0,T1/2,110,22,T1)+cyl(T1,14).translate([0,0,0])
fr=boxc(120+G['off'],0,T1/2,G['hx']+12,G['W']+12,T1)
b=b+fr
b=b-horn_cut(0,0,T1,**BIG)
b=b-servo_cut(G,120+G['off'],0,T1)
b=b-U(*[cyl(T1+2,4,24).translate([x,0,-1]) for x in (35,60,85)])   # aligerado
save(b,"05_brazo_120",1,"Eslabón hombro→codo (120 mm entre ejes). Lleva el MG996R del codo en su extremo.")
# 6) ANTEBRAZO (eslabón 2, 120 mm) ----------------------------------
T2=5
a=boxc(60,0,T2/2,115,18,T2)+cyl(T2,14)
a=a+boxc(120+S['off'],0,T2/2,S['hx']+9,S['W']+9,T2)
a=a-horn_cut(0,0,T2,**BIG)
a=a-servo_cut(S,120+S['off'],0,T2)
a=a-U(*[cyl(T2+2,3.5,24).translate([x,0,-1]) for x in (35,60,85)])
save(a,"06_antebrazo_120",1,"Eslabón codo→muñeca (120 mm entre ejes). Lleva el MG90S de la muñeca.")
# 7) CUERPO DE PINZA + mandíbula fija --------------------------------
T3=4
p=cyl(T3,10.5)+boxc(45,0.5,T3/2,90,39,T3)
p=p-horn_cut(0,0,T3,**SMALL)
sx,sy=30,-6                                  # eje del MG90S de la pinza
p=p-servo_cut(S,sx-S['off'],sy,T3)
mand=boxc(72,13,T3+10,36,4,20)               # mandíbula fija (pared) de x 54 a 90
p=p+mand+boxc(72,15,T3+1,36,8,2)
save(p,"07_pinza_cuerpo",1,"Se atornilla a la bocina de la muñeca. Sostiene el MG90S de la pinza y la mandíbula fija.")
# 8) MANDÍBULA MÓVIL ------------------------------------------------
T4=4
mm=cyl(T4,9)+boxc(30,0,T4/2,58,10,T4)
mm=mm+boxc(48,4,T4+4.5,30,3.5,9)            # pared de agarre que mira a la fija
mm=mm-horn_cut(0,0,T4,**SMALL)
save(mm,"08_pinza_mandibula_movil",1,"Va sobre la bocina del servo de la pinza. Al girar cierra contra la mandíbula fija.")
json.dump(INFO,open(f"{OUT}/info.json","w"),ensure_ascii=False,indent=1)
