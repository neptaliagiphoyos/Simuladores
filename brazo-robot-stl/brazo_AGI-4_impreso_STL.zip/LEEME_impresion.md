# Piezas impresas 3D · Brazo AGI-4 (versión 100 % impresa)

Medidas entre ejes: hombro a 86 mm de la mesa, brazo 120 mm, antebrazo 120 mm, muñeca a punta de pinza 90 mm. Alcance 330 mm.

| Archivo | Cant. | Para qué | PLA aprox. | Tiempo aprox. |
|---|---|---|---|---|
| 01_base_carcasa.stl | 1 | Piso y pared de la base (Ø140 × 34 mm). Dentro van ESP32, PCA9685 y bornera | 72 g | 6 h |
| 02_base_tapa.stl | 1 | Tapa con la ventana del MG996R de la base, con el eje al centro | 39 g | 3 h |
| 03_plato_giratorio.stl | 1 | Gira sobre el lazy susan y se une a la bocina del servo de la base | 50 g | 4 h |
| 04_soporte_hombro.stl | 1 | Mejilla en L que sostiene el MG996R del hombro de lado | 12 g | 1 h |
| 05_brazo_120.stl | 1 | Eslabón hombro → codo, con el MG996R del codo en la punta | 14 g | 1 h 10 min |
| 06_antebrazo_120.stl | 1 | Eslabón codo → muñeca, con el MG90S de la muñeca | 9 g | 45 min |
| 07_pinza_cuerpo.stl | 1 | Cuerpo de la pinza con mandíbula fija y ventana del MG90S de la pinza | 11 g | 1 h |
| 08_pinza_mandibula_movil.stl | 1 | Palanca con la mandíbula móvil, va en la bocina del servo de la pinza | 3 g | 15 min |

Total: unos 210 g de PLA y unas 17 h de impresión.

## Ajustes
PLA o PETG, capa 0,2 mm, 4 perímetros, relleno 30 % (base) y 50 % (eslabones y pinza). Sin soportes: cada pieza ya viene acostada en su mejor posición. El plato giratorio se imprime con la falda hacia arriba.

## Tornillería
- 4 tornillos M3 × 12 autorroscantes (tapa a carcasa).
- 4 tornillos M3 × 12 con tuerca (soporte de hombro a plato).
- 8 tornillos M3 × 10 con tuerca (orejas de los 3 MG996R en tapa, soporte y brazo; 4 ya traen los servos).
- 4 tornillos M2 × 8 autorroscantes (orejas de los 2 MG90S).
- Los tornillitos de la bolsa de cada servo fijan los eslabones a las bocinas por las 4 ranuras.

## Montaje en orden
1. Centra todos los servos en 90° con el código (`J 90 90 90 90 45`) antes de poner bocinas.
2. Servo de la base en la tapa, con el eje hacia arriba. Tapa sobre la carcasa (4 M3).
3. Lazy susan sobre la tapa, centrado, con 4 autorroscantes. Bocina redonda en el servo de la base.
4. Plato giratorio sobre el lazy susan: su cara interna toca la bocina. Atorníllalo a la bocina por las ranuras. Si queda luz entre plato y bocina, suplementa con arandelas; si roza, lija la falda.
5. Soporte de hombro sobre el plato (4 M3). MG996R del hombro en su ventana, con el eje **abajo**.
6. Brazo: en un extremo, a la bocina del hombro; en el otro va el MG996R del codo, también con el eje hacia el hombro.
7. Antebrazo a la bocina del codo; en su punta el MG90S de la muñeca.
8. Cuerpo de pinza a la bocina de la muñeca; MG90S de la pinza en su ventana; mandíbula móvil a esa bocina.
9. Calibra la pinza: busca el ángulo en que las mandíbulas se tocan y ponlo como cerrado (10 % en el simulador).

## Antes de imprimir todo
Imprime primero el **antebrazo** (45 min) y prueba que el MG90S entre en su ventana y que las ranuras calcen con tu bocina. Si tu MG996R no mide unos 40,7 × 19,7 mm o tu MG90S unos 22,8 × 12,2 mm, avísame y ajusto las medidas en `piezas_parametricas_impreso.py`.
