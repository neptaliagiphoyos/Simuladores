import manifold3d as m, numpy as np, trimesh, sys
M=m.Manifold
def box(x,y,z,center=False): return M.cube([x,y,z],center)
def cyl(h,r,n=64,center=False): return M.cylinder(h,r,r,n,center)
OUT=sys.argv[1]
def save(man,name):
    me=man.to_mesh(); t=trimesh.Trimesh(np.array(me.vert_properties)[:,:3],np.array(me.tri_verts))
    assert t.is_watertight, name
    t.export(f"{OUT}/{name}.stl"); print(name, t.bounds.round(2).tolist(), round(t.volume/1000,2),"cm3")
    return t
# ---------- 1. Adaptador bocina MG996R -> eje en cruz LEGO ----------
D=28; T=5
disk=cyl(T,D/2)
recess=cyl(2.2,3.9)                       # cabeza del tornillo central del servo
slots=None
for a in range(0,360,90):
    s=box(6.5,2.3,T+2).translate([5,-1.15,-1])   # ranura radial r=5..11.5 (calza cualquier bocina)
    s=s+cyl(T+2,1.15,24).translate([5,0,-1])+cyl(T+2,1.15,24).translate([11.5,0,-1])
    s=s.rotate([0,0,a+45]); slots=s if slots is None else slots+s
hub=cyl(9,5.5).translate([0,0,T])
cham=M.cylinder(1.01,2.6,3.3,48).translate([0,0,T+8])
for a,b,nm in [(4.95,1.95,"adaptador_bocina_MG996R_a_eje_LEGO"),(5.10,2.10,"adaptador_bocina_MG996R_a_eje_LEGO_holgado")]:
    cross=(box(a,b,12,True)+box(b,a,12,True)).translate([0,0,T+6.01])
    save(disk+hub-recess-slots-cross-cham,nm)
# ---------- 2. Soporte MG996R para vigas Technic ----------
L=72; W=40; PT=4
plate=box(L,W,PT).translate([-L/2,-W/2,0])
cut=box(41.0,20.6,PT+2).translate([-20.5,-10.3,-1])
holes=None
for sx in (-1,1):
    for sy in (-1,1):
        h=cyl(PT+2,1.7,32).translate([sx*49.5/2,sy*10/2,-1])
        holes=h if holes is None else holes+h
rails=None; railh=8; railw=7.2
for sy in (-1,1):
    r=box(L,railw,railh).translate([-L/2, sy*(W/2)-(railw if sy>0 else 0) ,-railh])
    rails=r if rails is None else rails+r
pins=None
for i in range(9):
    x=-32+i*8
    p=cyl(W+4,2.5,40).rotate([90,0,0]).translate([x,(W+4)/2,-railh/2])   # agujero pin Technic Ø4,8 + holgura
    pins=p if pins is None else pins+p
# agujeros verticales en el riel (para pines desde abajo), mismos 8 mm
vert=None
for i in range(9):
    for sy in (-1,1):
        v=cyl(PT+railh+2,2.5,40).translate([-32+i*8, sy*(W/2-railw/2), -railh-1])
        vert=v if vert is None else vert+v
# no perforar donde va el servo: los verticales quedan en los rieles (fuera del corte)
brk=plate+rails-cut-holes-pins
save(brk.rotate([180,0,0]).translate([0,0,4]),"soporte_MG996R_para_vigas_Technic")
