# Piezas impresas 3D · Brazo AGI-4 (versión LEGO)

| Archivo | Cantidad | Para qué | Material aprox. | Tiempo aprox. |
|---|---|---|---|---|
| adaptador_bocina_MG996R_a_eje_LEGO.stl | 2 | Une la bocina redonda o en cruz del MG996R con un eje en cruz LEGO (hombro y codo) | 4 g c/u | 25 min c/u |
| adaptador_bocina_MG996R_a_eje_LEGO_holgado.stl | 0 o 2 | Igual, con el agujero en cruz 0,15 mm más grande, por si el normal queda duro | 4 g c/u | 25 min c/u |
| soporte_MG996R_para_vigas_Technic.stl | 2 | Sostiene el MG996R y se une a las vigas con pines Technic (agujeros cada 8 mm) | 17 g c/u | 1 h 15 min c/u |

## Ajustes de impresión
- PLA o PETG, capa 0,2 mm, 4 perímetros, relleno 40 %, sin soportes.
- Los archivos ya vienen en la posición de impresión: el adaptador con el disco sobre la cama y el soporte con la placa sobre la cama y los rieles hacia arriba.

## Cómo se montan
1. **Adaptador:** atornilla primero la bocina al servo con su tornillo central. Luego apoya el adaptador sobre la bocina (el hueco de abajo deja espacio a la cabeza del tornillo) y fíjalo con 2 a 4 tornillos pequeños de la bolsa del servo, a través de las 4 ranuras. Las ranuras sirven para cualquier bocina.
2. Mete un eje en cruz LEGO en el agujero del adaptador. Debe entrar firme, sin martillar. Si queda duro, imprime la versión _holgado_.
3. **Soporte:** el servo entra por la ventana de 41 × 20,6 mm y se apoya en sus orejas. Fíjalo con 4 tornillos M3 × 10 y tuercas (separación 49,5 × 10 mm).
4. Une los rieles del soporte a las vigas Technic con pines (9 agujeros por lado, cada 8 mm).

## Antes de imprimir los dos
Imprime primero **un adaptador** (unos 25 minutos) y prueba el eje LEGO y la bocina. Mide tu MG996R con un vernier: si el cuerpo no mide unos 40,7 × 19,7 mm, avísame y ajusto el soporte.

`piezas_parametricas.py` es el modelo con sus medidas (Python + manifold3d), por si quieres cambiar alguna.
